# CSS Rolling Text

A Pen created on CodePen.io. Original URL: [https://codepen.io/marcell0lopes/pen/oNemQmB](https://codepen.io/marcell0lopes/pen/oNemQmB).

